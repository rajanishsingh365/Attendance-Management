//>>built
define("dijit/nls/nl/loading",({loadingState:"Bezig met laden...",errorState:"Er is een fout opgetreden"}));
